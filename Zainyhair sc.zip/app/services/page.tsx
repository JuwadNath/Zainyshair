import type { Metadata } from "next";
import ServiceCards from "@/components/ServiceCards";
export const metadata:Metadata={title:"Hair & Wig Services"};
export default function Services(){return <><section className="page-hero"><span className="eyebrow">What we do</span><h1>Find your feel-good style.</h1><p>Explore our hairstyling, wig studio and haircare services. Final recommendations and pricing are confirmed during your consultation.</p></section><section className="section"><div className="container"><ServiceCards/></div></section></>}
