import type { Metadata } from "next";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import WhatsApp from "@/components/WhatsApp";
import { site } from "@/lib/site";

export const metadata: Metadata = {
  title: { default: "ZAINY’S HAIR | Hair Salon & Wig Studio in Ajegunle, Lagos", template: "%s | ZAINY’S HAIR" },
  description: site.description,
  metadataBase: new URL("https://example.com"),
  openGraph: { title: "ZAINY’S HAIR — Beauty. Confidence. Elegance.", description: site.description, type: "website" }
};
export default function RootLayout({children}:{children:React.ReactNode}) {
  const schema = {"@context":"https://schema.org","@type":"HairSalon","name":site.name,"address":{"@type":"PostalAddress","streetAddress":"13 Barra Street, Ajegunle, Apapa","addressLocality":"Lagos","addressCountry":"NG"},"telephone":site.phoneDisplay,"url":"https://example.com","description":site.description};
  return <html lang="en"><body><script type="application/ld+json" dangerouslySetInnerHTML={{__html:JSON.stringify(schema)}}/><Header/><main>{children}</main><Footer/><WhatsApp/></body></html>;
}
