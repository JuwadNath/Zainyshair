import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const required = ["name","phone","service","preferred_date"];
    if (required.some((key) => !body[key] || typeof body[key] !== "string")) {
      return NextResponse.json({ error: "Please provide name, phone, service and preferred date." }, { status: 400 });
    }
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!url || !key) return NextResponse.json({ error: "Online booking storage is not configured. Please use the WhatsApp booking option." }, { status: 503 });
    const supabase = createClient(url, key);
    const { error } = await supabase.from("bookings").insert([{
      customer_name: body.name, phone: body.phone, service: body.service,
      preferred_date: body.preferred_date, preferred_time: body.preferred_time || null,
      notes: body.notes || null, status: "pending"
    }]);
    if (error) return NextResponse.json({ error: "We could not save the booking. Please try WhatsApp." }, { status: 500 });
    return NextResponse.json({ ok: true, message: "Your booking request has been received. The salon will contact you to confirm." });
  } catch {
    return NextResponse.json({ error: "Invalid request. Please try again." }, { status: 400 });
  }
}
