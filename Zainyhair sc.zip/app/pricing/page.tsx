import type { Metadata } from "next";
import { services } from "@/lib/site";
import Link from "next/link";
export const metadata:Metadata={title:"Service Pricing"};
export default function Pricing(){return <><section className="page-hero"><span className="eyebrow">Clear conversations, beautiful results</span><h1>Pricing & consultations.</h1><p>Service prices depend on hair length, style complexity, materials and the work required. Contact the salon for a quote before booking.</p></section><section className="section"><div className="container"><div className="price-list">{services.map(s=><div className="price-row" key={s.title}><span>{s.title}</span><span>Request a quote</span></div>)}</div><div style={{textAlign:"center",marginTop:30}}><Link href="/book" className="button button-dark">Enquire about a service</Link></div></div></section></>}
