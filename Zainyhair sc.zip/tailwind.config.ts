import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./app/**/*.{js,ts,jsx,tsx,mdx}", "./components/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: { extend: { colors: { ivory: "#F8F5F0", nude: "#E9D9CD", champagne: "#DCCBB8", gold: "#B99A70", espresso: "#292321" }, fontFamily: { serif: ["Georgia", "serif"] } } },
  plugins: []
};
export default config;
