export const site = {
  name: "ZAINY’S HAIR",
  tagline: "Beauty. Confidence. Elegance.",
  address: "13 Barra Street, Ajegunle, Apapa, Lagos, Nigeria",
  phoneDisplay: "09055655186",
  whatsapp: process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "2349055655186",
  instagram: "https://www.instagram.com/zainyhair8/",
  tiktokHandle: "ZAINYS HAIR",
  description: "Professional hairstyling, wig installation, wig revamping, braids and personalised haircare in Ajegunle, Apapa, Lagos."
};

export const services = [
  { title: "Wig Installation & Styling", description: "A neat, natural-looking finish tailored to your preferred look.", price: "Request a quote", category: "Wigs" },
  { title: "Frontal & Closure Installation", description: "Careful installation and styling for a seamless hairline.", price: "Request a quote", category: "Wigs" },
  { title: "Wig Revamping & Restoration", description: "Refresh, restyle and bring your favourite wig back to life.", price: "Request a quote", category: "Wigs" },
  { title: "Custom Wig Making", description: "A personalised wig made around your style and preferences.", price: "Request a quote", category: "Wigs" },
  { title: "Braids & Knotless Braids", description: "Beautiful protective styles with attention to neatness and comfort.", price: "Request a quote", category: "Styling" },
  { title: "Natural Hair Styling", description: "Styling options that celebrate and care for your natural hair.", price: "Request a quote", category: "Styling" },
  { title: "Hair Treatment & Care", description: "Haircare treatments selected around your hair’s needs.", price: "Request a quote", category: "Care" },
  { title: "Relaxing & Colouring", description: "Personalised chemical and colour services with consultation.", price: "Request a quote", category: "Care" },
  { title: "Bridal & Occasion Styling", description: "A polished hairstyle for celebrations and special moments.", price: "Request a quote", category: "Styling" },
  { title: "Hair Washing & Conditioning", description: "A refreshing wash and conditioning experience.", price: "Request a quote", category: "Care" }
];
