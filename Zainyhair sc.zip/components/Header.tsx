"use client";
import Link from "next/link";
import { useState } from "react";
import { Menu, X } from "lucide-react";

const links = [["Home","/"],["About","/about"],["Services","/services"],["Gallery","/gallery"],["Pricing","/pricing"],["Contact","/contact"]];
export default function Header() {
  const [open,setOpen] = useState(false);
  return <header className="site-header"><div className="nav-wrap">
    <Link href="/" className="brand"><span className="brand-mark">ZH</span><span><b>ZAINY’S</b><small>HAIR</small></span></Link>
    <nav className="desktop-nav">{links.map(([label,href])=><Link key={href} href={href}>{label}</Link>)}</nav>
    <Link className="button button-dark nav-cta" href="/book">Book Appointment</Link>
    <button className="menu-toggle" aria-label="Toggle navigation" onClick={()=>setOpen(!open)}>{open?<X/>:<Menu/>}</button>
  </div>{open&&<nav className="mobile-nav">{links.map(([label,href])=><Link onClick={()=>setOpen(false)} key={href} href={href}>{label}</Link>)}<Link onClick={()=>setOpen(false)} href="/book">Book Appointment</Link></nav>}</header>;
}
