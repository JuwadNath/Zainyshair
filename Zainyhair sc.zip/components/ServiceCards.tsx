import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { services } from "@/lib/site";
export default function ServiceCards({limit}:{limit?:number}){return <div className="service-grid">{services.slice(0,limit||services.length).map((s,i)=><article className="service-card" key={s.title}><div className="service-number">0{i+1}</div><span className="eyebrow">{s.category}</span><h3>{s.title}</h3><p>{s.description}</p><div className="service-bottom"><span>{s.price}</span><Link href={`/book?service=${encodeURIComponent(s.title)}`} aria-label={`Book ${s.title}`}><ArrowUpRight size={18}/></Link></div></article>)}</div>}
