import Link from "next/link";
import { MapPin, Instagram, MessageCircle } from "lucide-react";
import { site } from "@/lib/site";
export default function Footer(){return <footer className="footer"><div className="container footer-grid">
  <div><div className="footer-brand">ZAINY’S HAIR</div><p>{site.tagline}</p><p className="muted">Thoughtful hairstyling and wig services, created around your personal style.</p></div>
  <div><h4>Explore</h4><Link href="/about">About us</Link><Link href="/services">Our services</Link><Link href="/gallery">Hair gallery</Link><Link href="/pricing">Pricing</Link></div>
  <div><h4>Visit & connect</h4><p><MapPin size={15}/> {site.address}</p><p>{site.phoneDisplay}</p><a href={site.instagram} target="_blank" rel="noreferrer"><Instagram size={15}/> Instagram</a><a href={`https://wa.me/${site.whatsapp}`} target="_blank" rel="noreferrer"><MessageCircle size={15}/> WhatsApp</a></div>
</div><div className="copyright">© {new Date().getFullYear()} ZAINY’S HAIR. All rights reserved.</div></footer>}
