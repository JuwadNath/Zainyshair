import { MessageCircle } from "lucide-react";
import { site } from "@/lib/site";
export default function WhatsApp(){return <a className="whatsapp-float" href={`https://wa.me/${site.whatsapp}?text=${encodeURIComponent("Hello ZAINY’S HAIR, I would like to make an enquiry.")}`} target="_blank" rel="noreferrer" aria-label="Chat with ZAINY’S HAIR on WhatsApp"><MessageCircle/></a>}
