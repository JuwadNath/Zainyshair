# ZAINY’S HAIR website

A mobile-first Next.js website scaffold for ZAINY’S HAIR, Ajegunle, Apapa, Lagos.

## Included
- Home, About, Services, Gallery, Pricing, Booking and Contact pages
- Responsive navigation and WhatsApp floating action
- Booking enquiry form that composes a WhatsApp message
- Server-side Supabase booking endpoint and SQL schema
- Local SEO metadata and HairSalon structured data
- Basic private admin entry screen (see production notes)

## Run locally
1. Install Node.js 20 or later.
2. Copy `.env.example` to `.env.local` and set `NEXT_PUBLIC_WHATSAPP_NUMBER=2349055655186`.
3. Run `npm install`, then `npm run dev`.
4. Open http://localhost:3000.

## Connect online booking storage
1. Create a Supabase project.
2. Run `supabase-schema.sql` in the Supabase SQL editor.
3. Add `NEXT_PUBLIC_SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` to your deployment environment.
4. The booking API stores records in `public.bookings`. Keep the service-role key server-only.

## Important before launch
- Replace `https://example.com` in `app/layout.tsx` with the final domain.
- Replace the hero and gallery placeholders with original salon photos with customer permission. The current logo file is in `public/images/zainys-hair-logo.jpg`.
- Confirm the exact Google Maps pin, business hours, service prices, and contact/social profile URLs.
- Confirm the supplied phone number is the official WhatsApp number.
- The admin page is a starter placeholder, not a production-grade authenticated dashboard. The current login endpoint only checks a password and does not establish a secure session. Do not expose it publicly as an admin system. Use Supabase Auth with role-based access and audit logging before launch.
- Add rate limiting, spam protection, CSRF/origin controls, privacy notice, data retention policy and backups before accepting real customer data.
- Configure a real domain, HTTPS, analytics (with consent where required), and test on actual iOS/Android devices.

## Deployment
Deploy to Vercel or another Node-compatible host. Add the environment variables in the hosting dashboard and run `npm run build` before launch.
